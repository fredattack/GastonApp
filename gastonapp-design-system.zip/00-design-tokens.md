# Design Tokens

Primary: #8FA998
Secondary: #D4A574
Background: #F4F1E8
Font: Nunito
